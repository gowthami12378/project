import os
from django.conf import settings
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .models import EncryptedFile
from .forms import FileUploadForm
from .utils import encrypt_file, decrypt_file

def upload_file(request):
    """Handles file upload, encryption, and saving to the database."""
    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_file = request.FILES['file']
            file_data = uploaded_file.read()
            password = request.POST.get('password')

            if not password:
                return HttpResponse("⚠️ Password is required for encryption!", status=400)

            encrypted_data = encrypt_file(file_data, password)

            file_name = f"{uploaded_file.name}.enc"
            file_path = os.path.join('uploads', file_name)
            full_path = os.path.join(settings.MEDIA_ROOT, file_path)

            os.makedirs(os.path.dirname(full_path), exist_ok=True)

            with open(full_path, 'wb') as f:
                f.write(encrypted_data)

            encrypted_file = EncryptedFile(file=file_path)
            encrypted_file.save()

            return redirect('file_list')

    else:
        form = FileUploadForm()

    return render(request, 'locker/upload.html', {'form': form})

def file_list(request):
    """Displays the list of uploaded encrypted files."""
    files = EncryptedFile.objects.all()
    return render(request, 'locker/file_list.html', {'files': files})

def download_file(request, file_id):
    """Handles file decryption with a password and download."""
    file_obj = get_object_or_404(EncryptedFile, id=file_id)

    if request.method == 'POST':
        password = request.POST.get('password')
        file_path = os.path.join(settings.MEDIA_ROOT, file_obj.file.name)

        if not os.path.exists(file_path):
            return HttpResponse("File not found.", status=404)

        with open(file_path, 'rb') as f:
            encrypted_data = f.read()

        try:
            decrypted_data = decrypt_file(encrypted_data, password)
        except ValueError:
            return HttpResponse("❌ Incorrect password!", status=403)

        response = HttpResponse(decrypted_data, content_type='application/octet-stream')
        response['Content-Disposition'] = f'attachment; filename="{file_obj.file.name.replace('.enc', '')}"'
        return response

    return render(request, 'locker/decrypt.html', {'file': file_obj})

def delete_file(request, file_id):
    """Handles file deletion from the database and file system."""
    file_obj = get_object_or_404(EncryptedFile, id=file_id)

    file_path = os.path.join(settings.MEDIA_ROOT, file_obj.file.name)

    if os.path.exists(file_path):
        os.remove(file_path)

    file_obj.delete()

    return redirect('file_list')
