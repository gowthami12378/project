import base64
from django.db import models

class EncryptedFile(models.Model):
    file = models.FileField(upload_to='uploads/')
    encrypted_key = models.TextField()  # Store the key as base64 string

    def get_key(self):
        """Convert stored base64 key back to bytes."""
        return base64.b64decode(self.encrypted_key)  # Ensure bytes format
