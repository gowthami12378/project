from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.mail import send_mail
from django.conf import settings
from .models import CustomUser, OTP
import random

@receiver(post_save, sender=CustomUser)
def create_token(sender, instance, created, **kwargs):
    if created:
        # Generate OTP
        otp_code = str(random.randint(100000, 999999))
        
        # Create and save the OTP object
        otp = OTP.objects.create(
            user=instance,
            otp_code=otp_code
        )
        
        # Send email
        subject = 'Your OTP for Account Verification'
        message = f'Hi {instance.username}, here is your OTP: {otp_code}'
        from_email = settings.EMAIL_HOST_USER
        recipient_list = [instance.email]
        
        send_mail(
            subject,
            message,
            from_email,
            recipient_list,
            fail_silently=False,
        )
  
