# email_verification_django
This is a course on verifying users's email on signup using an OTP, that expires at every 5 minutes.
